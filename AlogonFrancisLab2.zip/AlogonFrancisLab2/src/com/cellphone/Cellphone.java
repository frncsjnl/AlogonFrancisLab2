package com.cellphone;

public class Cellphone {
	private String screen;
	private String OS;
	private int storage;
	private String processor;
	private int RAM;
	private String camera;
	private double bluetooth;
	private String ports;
	private String battery;
	private String color;
	
public Cellphone() {
	
}


public Cellphone(String screen, String OS, int storage, String processor, int RAM,
					String camera, double bluetooth, String ports, String battery,
					String color) {
		this.screen = screen;
		this.OS = OS;
		this.storage = storage;
		this.processor = processor;
		this.RAM = RAM;
		this.camera = camera;
		this.bluetooth = bluetooth;
		this.ports = ports;
		this.battery = battery;
		this.color = color;
	}


public void setScreen(String screen) {
	this.screen = screen;
}

public void setOS(String OS) {
	this.OS = OS;
}

public void setStorage(int storage) {
	this.storage = storage;
}

public void setProc(String processor) {
	this.processor = processor;
}

public void setRAM(int RAM){
	this.RAM = RAM;
}

public void setCam(String camera) {
	this.camera = camera;
}

public void setBT(double bluetooth) {
	this.bluetooth = bluetooth;
}

public void setPorts(String ports) {
	this.ports = ports;
}

public void setBat(String battery) {
	this.battery = battery;
}

public void setColor(String color) {
	this.color = color;
}

public String getScreen() {
	return this.screen;
}

public String getOS() {
	return this.OS;
}

public int getStorage() {
	return this.storage;
}

public String getProcessor() {
	return this.processor;
}

public int getRAM() {
	return this.RAM;
}

public String getCamera() {
	return this.camera;
}

public double getBT() {
	return this.bluetooth;
}

public String getPorts() {
	return this.ports;
}

public String getBattery() {
	return this.battery;
}

public String getColor() {
	return this.color;
}

public void display(String brand) {
	System.out.println("This phone's model is " + brand + ".");
}

}

