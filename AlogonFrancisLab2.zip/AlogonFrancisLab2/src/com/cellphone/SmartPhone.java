package com.cellphone;

public class SmartPhone extends Cellphone {
	int camRes;
	
	public SmartPhone() {
		
	}
	
	public SmartPhone(String screen, String OS, int storage, String processor, int RAM,
			String camera, double bluetooth, String ports, String battery,
			String color, int camRes) {
		super(screen, OS, storage, processor, RAM, camera, bluetooth, ports, battery, color);
		this.camRes = camRes;
	}
	
	public void setCamRes(int camRes) {
		this.camRes = camRes;
	}
	
	public int getCamRes() {
		return this.camRes;
	}
}

