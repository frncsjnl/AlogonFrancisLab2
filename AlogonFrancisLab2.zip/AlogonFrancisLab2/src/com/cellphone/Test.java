package com.cellphone;

public class Test {

	public static void main(String[] args) {
		Cellphone c1 = new Cellphone();
		
		System.out.println("Smartphone");
		c1.display("Samsung Galaxy S10");
		c1.setScreen("6.2-inch Dynamic AMOLED");
		c1.setOS("Android 10");
		c1.setStorage(128);
		c1.setProc("Qualcomm Snapdragon 865");
		c1.setRAM(12);
		c1.setCam("12 megapixel, 64MP telephoto, 10MP front");
		c1.setBT(5.0);
		c1.setPorts("USB-C");
		c1.setBat("4,000mAh");
		c1.setColor("Cosmic Gray, Cloud Pink, Cloud Blue");
		
		System.out.println("Screen size: " + c1.getScreen());
		System.out.println("Operating System: " + c1.getOS());
		System.out.println("Storage: " + c1.getStorage() + "GB");
		System.out.println("Processor: " + c1.getProcessor());
		System.out.println("RAM: " + c1.getRAM() + "GB");
		System.out.println("Camera: " + c1.getCamera());
		System.out.println("Bluetooth Version: " + c1.getBT());
		System.out.println("Ports: " + c1.getPorts());
		System.out.println("Battery: " + c1.getBattery());
		System.out.println("Colors Available: " + c1.getColor());
		
		SmartPhone sp1 = new SmartPhone();
		System.out.println("");
		c1.display("Iphone 11");
		sp1.setScreen("5.8-inch Super Retina XDR OLED");
		sp1.setOS("iOS 13");
		sp1.setStorage(512);
		sp1.setProc("Apple A13 Bionic");
		sp1.setRAM(4);
		sp1.setCam("12 megapixel, 12MP telephoto, 12MP front");
		sp1.setBT(5.0);
		sp1.setPorts("Lightning");
		sp1.setBat("3,046mAh");
		sp1.setColor("Midnight Green, Space Grey, Silver, Gold");
		
		System.out.println("Screen size: " + sp1.getScreen());
		System.out.println("Operating System: " + sp1.getOS());
		System.out.println("Storage: " + sp1.getStorage() + "GB");
		System.out.println("Processor: " + sp1.getProcessor());
		System.out.println("RAM: " + sp1.getRAM() + "GB");
		System.out.println("Camera: " + sp1.getCamera());
		System.out.println("Bluetooth Version: " + sp1.getBT());
		System.out.println("Ports: " + sp1.getPorts());
		System.out.println("Battery: " + sp1.getBattery());
		System.out.println("Colors Available: " + sp1.getColor());
	}

}
